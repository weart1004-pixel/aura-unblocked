Aura Unblocked Retro Bowl update

Copy index.html into the repository root, replacing the existing file. Copy the full games/retro-bowl-modded/ directory into the repository's games/ directory. Commit and push to main; GitHub Pages will publish the change.

The catalog entry adds Retro Bowl under Sports. The game loads from the local site, and its mod menu script is only loaded after the existing visitor API verifies the site's owner token.
